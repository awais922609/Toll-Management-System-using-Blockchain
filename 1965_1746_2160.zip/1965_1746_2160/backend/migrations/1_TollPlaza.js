const TollPlaza = artifacts.require("TollPlaza");

module.exports = function (deployer) {
  deployer.deploy(TollPlaza);
};
